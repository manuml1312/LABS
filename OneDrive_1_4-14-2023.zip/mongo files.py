import pymongo
import gridfs

# Connect to MongoDB
client = pymongo.MongoClient('mongodb+srv://Manu:Manu1312@cluster0.ja3xqvn.mongodb.net/?retryWrites=true&w=majority')
db = client['ai_360']

# Create a GridFS instance
fs = gridfs.GridFS(db)

# #Store a text file:
# with open('example.txt', 'rb') as f:
#     file_id = fs.put(f, filename='example.txt', content_type='text/plain')

# # Store an image file
# with open('/home/manu/Pictures/puzzle.jpg', 'rb') as f:
#     file_id = fs.put(f, filename='/home/manu/Pictures/puzzle.jpg', content_type='image/jpeg')

# # Store an audio file
# with open('/home/manu/Downloads/TTS/male.mp3', 'rb') as f:
#     file_id = fs.put(f, filename='/home/manu/Downloads/TTS/male.mp3', content_type='audio/mpeg')

# # Store a video file
# with open('example.mp4', 'rb') as f:
#     file_id = fs.put(f, filename='example.mp4', content_type='video/mp4')

# # Store a PDF file
# with open('example.pdf', 'rb') as f:
#     file_id = fs.put(f, filename='example.pdf', content_type='application/pdf')

# for file in fs.find():
#     # Get the file content type
#     content_type = file.content_type

#     if content_type.startswith('text'):# Read the file data
#        data = file.read()
#        # Print the file data
#        print(data.decode('utf-8'))
#      # Save the file to disk
#        with open('my_file.txt', 'w') as f:
#           f.write(data.decode('utf-8'))


    # if content_type.startswith('image/jpeg'):# Read the file data
    #    data = file.read()
    #    #print(data)
    #  # Save the file to disk
    #    with open('my_file.jpg', 'wb') as f:
    #       f.write(data)

    # if content_type.startswith('audio/mpeg'):# Read the file data
    #    data = file.read()
    #    # Print the file data
    #    #print(data)
    #  # Save the file to disk
    #    with open('my_file.mp3', 'wb') as f:
    #       f.write(data)


#     if content_type.startswith('video/mp4'):# Read the file data
#        data = file.read()
#        # Print the file data
#        print(data)
#      # Save the file to disk
#        with open('my_file.mp4', 'wb') as f:
#           f.write(data)


#     if content_type.startswith('application/pdf'):# Read the file data
#        data = file.read()
#        # Print the file data
#        print(data.decode('utf-8'))
#      # Save the file to disk
#        with open('my_file.pdf', 'w') as f:
#           f.write(data)
    
#     else:
#        print("File format not in record")
const mongoose = require('mongoose');
const fs = require('fs');
const { GridFSBucket, ObjectId } = require('mongodb');

// Connection URI
const uri = 'mongodb+srv://Manu:Manu1312@cluster0.ja3xqvn.mongodb.net/ai_360?retryWrites=true&w=majority';

// Connect to the MongoDB server
mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');

    const db = mongoose.connection.db;
    const bucket = new GridFSBucket(db);

    // Upload a file
    const filename = 'seal11.txt';
    const filepath = './seal11.txt';
    const contentType = 'text';
    const uploadStream = bucket.openUploadStream(filename, { contentType });
    const readStream = fs.createReadStream(filepath);
    readStream.pipe(uploadStream);
    uploadStream.on('finish', () => {
      console.log('File stored successfully');

      // Download the file
      const downloadStream = bucket.openDownloadStreamByName(filename);
      downloadStream.pipe(fs.createWriteStream(`./alpha.txt`));
      downloadStream.on('end', () => {
        console.log('File downloaded successfully');

        // Retrieve the file from database
        const retrievedFile = db.collection('fs.files').findOne({ filename });
        console.log('Retrieved file:', retrievedFile);

        // Close the MongoDB connection
        mongoose.connection.close();
      });
      downloadStream.on('error', (error) => {
        console.error('Error downloading file:', error);

        // Close the MongoDB connection
        mongoose.connection.close();
      });
    });
    uploadStream.on('error', (error) => {
      console.error('Error storing file:', error);

      // Close the MongoDB connection
      mongoose.connection.close();
    });
  })
  .catch((err) => {
    console.error('Failed to connect to MongoDB:', err);
  });

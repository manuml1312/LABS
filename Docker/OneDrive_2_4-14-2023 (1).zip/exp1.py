import sys
import json
import warnings
warnings.filterwarnings("ignore")
text=sys.argv[1]
from transformers import pipeline
summarizer=pipeline('summarization',model='lidiya/bart-base-samsum')
print(json.dumps(summarizer(text)))

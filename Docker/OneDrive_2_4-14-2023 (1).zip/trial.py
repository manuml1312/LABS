
from transformers import AutoModelForSeq2SeqLM,AutoTokenizer#print('Stage2')
import warnings
warnings.filterwarnings("ignore")
from transformers import pipeline

#config = AutoConfig.from_pretrained('lidiya/bart-base-samsum')
#model = AutoModelForSeq2SeqLM.from_pretrained("lidiya/bart-base-samsum")
#tokenizer=AutoTokenizer.from_pretrained("lidiya/bart-base-samsum")
m=AutoModelForSeq2SeqLM.from_pretrained('lidiya/bart-base-samsum')
t=AutoTokenizer.from_pretrained('lidiya/bart-base-samsum')
text="""In the above example, the require() function returns
 an object because the Http module returns its functionality
  as an object. The function http.createServer() method will
   be executed when someone tries to access the computer on port 
   3000. The res.writeHead() method is the status code where 200 
   means it is OK, while the second argument is an object containing the
    response headers."""
input = t(text,return_tensors='pt')
summary_id = m.generate(input['input_ids'])
y=t.batch_decode(summary_id,skip_special_tokens=True,clean_up_tokenization_spaces=False)[0]
print(y)

const spawn = require("child_process").spawn;


const questions = JSON.stringify('Hello World machine learning dynamic learning advanced neural nets techs')
const pythonprocess = spawn('python3',["./exp.py",questions],{
  shell: true,
  env:{
    ...process.env
  }
});
// console.log("am here1")
pythonprocess.stdout.on('data',(data) => {

    console.log(data.toString());
});
console.log("nodejs is working")


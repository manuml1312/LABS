from pymongo import MongoClient
from transformers import pipeline
import pandas as pd

client = MongoClient('mongodb+srv://Manu:Manu1312@cluster0.ja3xqvn.mongodb.net/?retryWrites=true&w=majority')
mydb=client['ai_360']
myc1=mydb['answers']

d={}
i=0
for x in myc1.find({},{'_id':0}):
  d[i]=x
  i=i+1

summarizer=pipeline('summarization',model='lidiya/bart-base-samsum')

df=pd.DataFrame(d)
text=list(df[0].values)

x=''
ops=[]
for i in text:
    x=summarizer(i)
    ops.append(x)
    print(x)



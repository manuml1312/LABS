console.log("am here1")
console.log("nodejs is working")

// pythonprocess.stderr.on('err',(err) =>{
//   console.log(err);
// })

    //console.log(JSON.parse(data))
    //resultdata = JSON.parse(data);

    
//const express = require('express')
//var resultdata = '';
//Constants
//const PORT = 8080
//const HOST = '0.0.0.0';

//const app = express();

//var resultdata = '';
//app.get('/',(req,res) => {
  //  res.send(resultdata);
//});

//app.listen(PORT,HOST);
//console.log(`Running on http://${HOST}:${PORT}`);
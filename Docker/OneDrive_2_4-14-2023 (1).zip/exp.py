import json
import warnings
warnings.filterwarnings("ignore")
text="""In the above example, the require() function returns
 an object because the Http module returns its functionality
  as an object. The function http.createServer() method will
   be executed when someone tries to access the computer on port 
   3000. The res.writeHead() method is the status code where 200 
   means it is OK, while the second argument is an object containing the
    response headers."""


#,AutoConfig,AutoModelForSeq2SeqLM,AutoTokenizer
#config = AutoConfig.from_pretrained("lidiya/bart-base-samsum")
# model = AutoModelForSeq2SeqLM.from_pretrained("lidiya/bart-base-samsum")
# tokenizer=AutoTokenizer.from_pretrained("lidiya/bart-base-samsum")
# tokenizer.save_pretrained("./tokenizer",cache="./tokenizer")
# model.save_pretrained("./model",cache="./model")

#from transformers import AutoConfig

#config = AutoConfig.from_pretrained("./model")
#model = AutoModelForSeq2SeqLM.from_pretrained("./model",config=config)
#tokenizer=AutoTokenizer.from_pretrained("./tokenizer")
# um")
#print(text)

#summarizer = AutoModelForSeq2SeqLM.from_pretrained('Model')
#tokenizer = AutoTokenizer.from_pretrained('Model')
#summarizer=pipeline('summarization')
#input = tokenizer(text,return_tensors='pt')
#summary_id = model.generate(input['input_ids'])
#y=tokenizer.batch_decode(summary_id,skip_special_tokens=True,clean_up_tokenization_spaces=False)[0]
#print(json.dumps(y))
#print(json.dumps(y))
#print(json.dumps(text))

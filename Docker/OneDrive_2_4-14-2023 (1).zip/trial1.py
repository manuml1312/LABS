import sys
import json
text=sys.argv[1]
print(json.dumps(text))
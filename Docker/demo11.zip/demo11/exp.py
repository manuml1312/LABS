i=0
while(i<1):
    pass
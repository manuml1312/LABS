#to export data to mongodb
from pymongo import MongoClient
client = MongoClient('mongodb+srv://Manu:Manu1312@cluster0.ja3xqvn.mongodb.net/?retryWrites=true&w=majority')
mydb=client['ai_360']
#myc1=mydb['questions']
#dd1={'q1':'Define the problem','q2':"""Describe the current solution 
#in greater detail, along with performance"""}

myc2=mydb['answers']

dd2={'q1':"""Customer churn analysis \
for an elevator/lift company. We need to \
predict the churn from one month of the prediction date to the next \
12 months using historical data""",'q2':"""The human judgment. \
Currently, the notice with which predictions \
are made is less than a month (giving no time to react to the business). \
 The precision is 2percent for a recall of 20%"""}

#myc1.insert_one(dd1)
myc2.insert_one(dd2)

print('done')
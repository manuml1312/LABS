const mongoose = require('mongoose')

var url = 'mongodb+srv://param:vChYvshCaXUm5SlA@cluster0.ja3xqvn.mongodb.net/?retryWrites=true&w=majority/ai_360'

const myobj = {'q1': "Customer churn analysis \
    for an elevator lift company. We need to\
    predict the churn from one month of the prediction date to the next \
    12 months using historical data", 'q2': "The human judgment Currently,the notice with which predictions \
    are made is less than a month (giving no time to react to the business).\
    The precision is 2percent for a recall of 20%"};
  

mongoose.connect(url,(err,db) => {
  if (err) throw err;
  // const db1 = db.createCollection('answers');
  // db1.createCollection("answers",(err,results) => {
  //   if (err) throw err;
  //   console.log("Collection created");
    });
// });
  
    // db1.collection('answers').insertOne(myobj,(err,results) => {
    //   if (err) throw err;
    //   console.log("Inserted")
    // db1.close()
  // });

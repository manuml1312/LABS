from transformers import pipeline, AutoModelForSeq2SeqLM, AutoTokenizer
import pandas as pd
import os
import pickle
print("loading Pickle file")
model_1 = pickle.load(open('model_1.pkl','rb'))

print("loading done")
text = """The end user of the deep learning application is a data scientist working in the field of image recognition. They will use the application to analyze and classify large volumes of images, such as photographs and video frames. The deep learning model has been trained on a diverse dataset of images and is able to accurately identify and classify objects, scenes, and people within the images.

The data scientist will access the application through a secure website on their desktop computer, and will use it to perform a variety of tasks such as identifying patterns and trends in the images, extracting metadata, and generating reports and visualizations. They will also be able to customize the model's parameters to optimize its performance for specific tasks and datasets.

Overall, the deep learning application will significantly improve the data scientist's productivity and ability to extract valuable insights from image data, making it an essential tool in their work."""
print("summarizing")
print(model_1(text))

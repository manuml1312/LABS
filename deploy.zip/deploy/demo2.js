var spawn = require("child_process").spawn;
               
const questions = JSON.stringify('Hello World machine learning dynamic learning advanced neural nets techs')
var pythonProcess = spawn('python',["./exp.py",questions]);


pythonProcess.stdout.on('data', function (data){                    
    console.log(data.toString('utf8'));                    
});

pythonProcess.stderr.on('data', function (data){
    console.log(data.toString('utf8').replace(/[\n\r]/g, ''));
});
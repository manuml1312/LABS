import sys
import json
import warnings
warnings.filterwarnings("ignore")

from transformers import pipeline
m=pipeline('summarization',model='lidiya/bart-large-xsum-samsum')

text=sys.argv[0]
print('text in!')
output=m(text)[0]['summary_text']
print('done')

print(json.dumps(output))

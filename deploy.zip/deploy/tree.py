import sys
#from transformers import AutoModelForSeq2SeqLM,AutoTokenizer#print('Stage2')
import warnings
warnings.filterwarnings("ignore")
from transformers import pipeline
m=pipeline('summarization',model='lidiya/bart-large-xsum-samsum')
text=sys.argv[1]
print(m(text))